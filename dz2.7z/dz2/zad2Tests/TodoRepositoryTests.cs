﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TodoLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoLib.Tests
{
	[TestClass()]
	public class TodoRepositoryTests
	{

		[TestMethod()]
		public void GetTest()
		{
			TodoRepository repo = new TodoRepository();
			Guid id = new Guid();
			Assert.IsNull(repo.Get(id));

			TodoItem a = repo.Add(new TodoItem("blah"));
			id = a.Id;
			Assert.IsNotNull(repo.Get(id));

		}

		[TestMethod()]
		[ExpectedException(typeof(TodoRepository.DuplicateTodoItemException))]
		public void AddTest()
		{
			TodoRepository repo = new TodoRepository();

			TodoItem b = new TodoItem("blah");
			TodoItem a = repo.Add(b);
			Assert.IsNotNull(a);	//adding an item

			repo.Add(b); //adding a duplicate throws an exception
		}

		[TestMethod()]
		public void RemoveTest()
		{
			TodoRepository repo = new TodoRepository();
			Guid id = new Guid();
			Assert.IsFalse(repo.Remove(id)); //remove item from empty repo

			TodoItem a = new TodoItem("blah");
			repo.Add(a);
			Assert.IsTrue(repo.Remove(a.Id)); //remove item
			Assert.IsFalse(repo.Remove(a.Id)); //try removing an already removed item
		}

		[TestMethod()]
		public void UpdateTest()
		{
			TodoRepository repo = new TodoRepository();
			Guid id = new Guid();
			TodoItem a = new TodoItem("blah");
			Assert.IsNotNull(repo.Update(a));	//add item to empty repo

			a.Text = "changed text";
			Assert.AreEqual(a, repo.Update(a)); //the item and "Get(item.Id)" return the same value after swap
		}

		[TestMethod()]
		public void MarkAsCompletedTest()
		{
			TodoRepository repo = new TodoRepository();
			TodoItem a = new TodoItem("blah");

			Assert.IsFalse(repo.MarkAsCompleted(a.Id));//marking an item (that is not in the repo) as complete returns false

			repo.Add(a);
			Assert.IsTrue(repo.MarkAsCompleted(a.Id)); //completing an existing item returns true
			Assert.IsFalse(repo.MarkAsCompleted(a.Id)); //completing an already completed item returns false

		}

		[TestMethod()]
		public void GetAllTest()
		{
			Assert.Fail();
		}

		[TestMethod()]
		public void GetActiveTest()
		{
			Assert.Fail();
		}

		[TestMethod()]
		public void GetCompletedTest()
		{
			Assert.Fail();
		}

		[TestMethod()]
		public void GetFilteredTest()
		{
			Assert.Fail();
		}
	}
}