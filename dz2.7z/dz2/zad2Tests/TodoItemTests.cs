﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TodoLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoLib.Tests
{
	[TestClass()]
	public class TodoItemTests
	{

		[TestMethod()]
		public void MarkAsCompletedTest()
		{
			TodoItem a = new TodoItem("opis");

			Assert.IsTrue(a.MarkAsCompleted());
			Assert.IsFalse(a.MarkAsCompleted());

		}

		[TestMethod()]
		public void EqualsTest()
		{
			TodoItem a = new TodoItem("bla");
			TodoItem b = new TodoItem("bla");
			TodoItem c = a;
			Assert.IsFalse(a.Equals(b));
			Assert.IsTrue(a.Equals(c));
		}
	}
}