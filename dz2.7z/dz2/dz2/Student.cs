﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentLib
{
    public class Student
    {
		public string Name { get; set; }
		public string Jmbag { get; set; }
		public Gender Gender { get; set; }

	    public Student(string name, string jmbag)
	    {
		    Name = name;
		    Jmbag = jmbag;
	    }

	    public static void Case1()
	    {
		    var topStudents = new List<Student>()
		    {
			    new Student("Ivan", jmbag: "001234567"),
			    new Student("Luka", jmbag: "3274272"),
			    new Student("Ana", jmbag: "9382832")
		    };

		    var ivan = new Student("Ivan", jmbag: "001234567");
		    bool isIvanTopStudent = topStudents.Contains(ivan);
			Console.WriteLine(isIvanTopStudent);
		}
	
	    public static void Case2()
	    {
		    var list = new List<Student>()
		    {
			    new  Student("Ivan", jmbag:"001234567"),
			    new  Student("Ivan", jmbag:"001234567")
		    };
		    var distinctStudentsCount = list.Distinct().Count();
			Console.WriteLine(distinctStudentsCount);
	    }

	    public static void Case3()
	    {
		    var topStudents = new List<Student>()
		    {
			    new  Student("Ivan", jmbag:"001234567"),
			    new  Student("Luka", jmbag:"3274272"),
			    new  Student("Ana", jmbag:"9382832")
		    };
		    var ivan = new Student("Ivan", jmbag: "001234567");
		    // false :(
		    // ==  operator  is a different  operation  from .Equals ()
		    // Maybe it isn ’t such a bad  idea to  override  it as well
		    bool isIvanTopStudent = topStudents.Any(s => s == ivan);
		    Console.WriteLine(isIvanTopStudent);
	    }
		
	    public override bool Equals(Object obj)
	    {
		    if (obj == null || GetType() != obj.GetType())
			    return false;
		    Student s = (Student)obj;
			return ((Name == s.Name) && (Jmbag == s.Jmbag));
	    }

	    public static bool operator ==(Student s1, Student s2)
	    {
		    return s1.Equals(s2);
	    }
	    public static bool operator !=(Student s1, Student s2)
	    {
		    return !s1.Equals(s2);
	    }

	    public override int GetHashCode()
	    {
		    return Name.GetHashCode() ^ Jmbag.GetHashCode();
	    }
    }

	public enum Gender
	{
		Male, Female
	}

	
}
