﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GenericListLib;
using StudentLib;
using TodoLib;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			/*
			Student.Case1();
			Student.Case2();
			Student.Case3();
			*/
			TodoRepository repo = new TodoRepository();
			Guid id = new Guid();
			TodoItem a = new TodoItem("blah");
			repo.Update(a);
			/*
			//testing the enumerability of GenericList
			GenericList<string> myList = new GenericList<string>();
			myList.Add("bla");
			myList.Add("blo");
			myList.Add("ble");
			foreach (string s in myList)
			{
				Console.WriteLine(s);
			}*/
		}
	}
}
