﻿using System;
using System.Collections.Generic;
using GenericListLib;
using System.Linq;
using System.Threading;

namespace TodoLib
{
	/// <summary >
	/// Class  that  encapsulates  all  the  logic  for  accessing  TodoTtems.
	/// </summary >
	public class TodoRepository : ITodoRepository
	{
		/// <summary >
		/// Repository  does  not  fetch  todoItems  from  the  actual  database ,
		/// it uses in  memory  storage  for  this  excersise.
		///  </summary >
		private readonly IGenericList<TodoItem> _inMemoryTodoDatabase;

		//private bool comopleted;
		
		public TodoRepository(IGenericList<TodoItem> initialDbState = null)
		{
			if (initialDbState != null)
				_inMemoryTodoDatabase = initialDbState;
			else
				_inMemoryTodoDatabase = new GenericList<TodoItem>();
		}

		
		public TodoItem Get(Guid todoId)
		{
			var a = from n in _inMemoryTodoDatabase
				where n.Id == todoId
				select n;
			TodoItem res;
			if (a.Any())
				res = a.First();
			else res = null;
			return res;
		}

		public TodoItem Add(TodoItem todoItem)
		{
			if (_inMemoryTodoDatabase.Contains(todoItem))
			{
				throw new DuplicateTodoItemException($"duplicate  id: {todoItem.Id}");
			}
			_inMemoryTodoDatabase.Add(todoItem);
			return todoItem;
		}

		public class DuplicateTodoItemException : Exception
		{
			public DuplicateTodoItemException()
			{
			}

			public DuplicateTodoItemException(string message)
				: base(message)
			{
			}

			public DuplicateTodoItemException(string message, Exception inner)
				: base(message, inner)
			{
			}
		}

		public bool Remove(Guid todoId)
		{
			TodoItem res = Get(todoId);
			try
			{
				return _inMemoryTodoDatabase.Remove(res);
			}
			catch (IndexOutOfRangeException e)
			{
				return false;
			}
		}

		public TodoItem Update(TodoItem todoItem)
		{
			if (_inMemoryTodoDatabase.Contains(todoItem))
				Remove(todoItem.Id);
			Add(todoItem);
			return Get(todoItem.Id);
		}

		public bool MarkAsCompleted(Guid todoId)
		{
			if (_inMemoryTodoDatabase.Contains(Get(todoId)))
				return(Get(todoId).MarkAsCompleted());
			else
				return false;
		}

		public List<TodoItem> GetAll()
		{
			var res = from n in _inMemoryTodoDatabase
				orderby n.DateCreated descending
				select n;
			return (List<TodoItem>)res;
		}

		public List<TodoItem> GetActive()
		{
			var res = from n in _inMemoryTodoDatabase
				where !n.IsCompleted
				select n;
			return (List<TodoItem>) res;
		}

		public List<TodoItem> GetCompleted()
		{
			var res = from n in _inMemoryTodoDatabase
				where n.IsCompleted
				select n;
			return (List<TodoItem>)res;
		}

		public List<TodoItem> GetFiltered(Func<TodoItem, bool> filterFunction)
		{
			var res = from n in _inMemoryTodoDatabase
				where filterFunction(n)
				select n;
			return (List<TodoItem>) res;
		}
	}
}