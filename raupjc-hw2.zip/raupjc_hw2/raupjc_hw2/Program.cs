﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace raupjc_hw2
{
	class Program
	{
		static void Main(string[] args)
		{
			Case1();
			Case2();
			Case3();
		}



		static void Case1()
		{
			var topStudents = new List<Student>()
			{
				new Student("Ivan", jmbag: "001234567"),
				new Student("Luka", jmbag: "3274272"),
				new Student("Ana", jmbag: "9382832")
			};

			var ivan = new Student("Ivan", jmbag: "001234567");

			bool isIvanTopStudent = topStudents.Contains(ivan);
		}



		static void Case2()
		{
			var list= new List<Student>()
			{
				new Student("Ivan", jmbag: "001234567"),
				new Student("Ivan", jmbag: "001234567"),
			};

			var distinctStudentsCount = list.Distinct().Count();
		}



		static void Case3()
		{
			var topStudents = new List<Student>()
			{
				new Student("Ivan", jmbag: "001234567"),
				new Student("Luka", jmbag: "3274272"),
				new Student("Ana", jmbag: "9382832"),
			};

			var ivan = new Student("Ivan", jmbag: "001234567");

			bool isIvanTopStudent = topStudents.Any(s => s == ivan);
		}

		
	}





	public class Student
	{
		public string Name { get; set; }
		public string Jmbag { get; set; }
		public Gender Gender { get; set; }

		public Student(string name, string jmbag)
		{
			Name = name;
			Jmbag = jmbag;
		}

		public static bool operator == (Student s1, Student s2)
		{
			return (s1.Equals(s2));
		}

		public static bool operator != (Student s1, Student s2)
		{
			return !(s1.Equals(s2));
		}

		public override bool Equals(object o)
		{
			if (o == null || this.GetType() != o.GetType())
				return false;
			Student s = (Student) o;
			return (this.Name == s.Name && this.Jmbag == s.Jmbag);
		}

		public override int GetHashCode()
		{
			return Jmbag.GetHashCode();
		}
	}

	public enum Gender
	{
		Male, Female
	}

	
}
