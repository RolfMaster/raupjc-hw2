﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Tests
{
	[TestClass()]
	public class TodoRepositoryTests
	{

		[TestMethod()]
		public void AddGetTest()
		{
			TodoRepository repo = new TodoRepository();
			TodoItem it = new TodoItem("testingg..");

			repo.Add(it);
			TodoItem res = repo.GetAll().First();

			Assert.AreEqual(res, it);
		}

		[TestMethod()]
		public void RemoveTest()
		{
			TodoRepository repo = new TodoRepository();
			TodoItem it = new TodoItem("blabla");
			repo.Add(it);
			repo.Remove(it.Id);

			Assert.IsFalse(repo.GetAll().Contains(it));
		}

		[TestMethod()]
		public void UpdateTest()
		{
			TodoRepository repo = new TodoRepository();
			TodoItem it = new TodoItem("testinjo");
			TodoItem ot = new TodoItem("testinjer");


			repo.Add(it);
			repo.Update(it);
			repo.Update(ot);

			Assert.IsTrue(repo.GetAll().Contains(it));
			Assert.IsTrue(repo.GetAll().Contains(ot));
		}

		[TestMethod()]
		public void MarkAsCompletedTest()
		{
			TodoRepository repo = new TodoRepository();
			TodoItem it = new TodoItem("testinjo");

			repo.Add(it);
			Assert.IsFalse(repo.Get(it.Id).IsCompleted);
			repo.MarkAsCompleted(it.Id);
			Assert.IsTrue(repo.Get(it.Id).IsCompleted);
		}

		[TestMethod()]
		public void VariousGetsTest()
		{
			TodoRepository repo = new TodoRepository();
			TodoItem it = new TodoItem("testinjo");

			GenericList<TodoItem> list = new GenericList<TodoItem>();
			for (int i = 0; i < 5; i++)
			{
				list.Add(new TodoItem(i.ToString()));
			}

			foreach (TodoItem ite in list)
			{
				repo.Add(ite);
			}

			Assert.AreEqual(list.Count, repo.GetAll().Count);

			repo.MarkAsCompleted(list.First().Id);

			Assert.AreEqual(list.Count-1, repo.GetActive().Count);
			Assert.AreEqual(1, repo.GetCompleted().Count);
		}

		[TestMethod()]
		public void GetFilteredTest()
		{
			TodoRepository repo = new TodoRepository();
			TodoItem it = new TodoItem("testinjo");

			TodoItem theone = new TodoItem("blo");
			for (int i = 0; i < 5; i++)
			{
				if (i == 4)
				{
					theone = new TodoItem("4");
					repo.Add(theone);
				}
				repo.Add(new TodoItem(i.ToString()));
			}
			
			bool fankshn(TodoItem itemo)
			{
				return itemo.Text == "4";
			}

			Assert.AreEqual(repo.GetFiltered(fankshn).First(), theone);
		}
	}
}