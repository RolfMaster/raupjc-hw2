﻿using System;

namespace ConsoleApp1
{
	public class TodoItem
	{
		public Guid Id { get; set; }
		public string Text { get; set; }

		public bool IsCompleted => DateCompleted.HasValue;

		public DateTime? DateCompleted { get; set; }
		public DateTime DateCreated { get; set; }

		public TodoItem(string text)
		{
			Id = Guid.NewGuid();
			this.Text = text;
			DateCreated = DateTime.UtcNow;
		}

		public bool MarkAsCompleted()
		{
			if (!IsCompleted)
			{
				DateCompleted = DateTime.Now;
				return true;
			}

			return false;
		}

		public override bool Equals(object obj)
		{
			if (obj == null || GetType() != obj.GetType())
				return false;

			return Id.Equals(((TodoItem)obj).Id);
		}

		public override int GetHashCode()
		{
			return Id.GetHashCode();
		}
	}
}