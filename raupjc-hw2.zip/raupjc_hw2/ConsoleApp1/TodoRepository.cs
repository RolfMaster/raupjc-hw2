﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1
{
	public class TodoRepository : ITodoRepository
	{

		private readonly IGenericList<TodoItem> _inMemoryTodoDatabase;

		public TodoRepository(IGenericList<TodoItem> initialDbState = null)
		{
			if (initialDbState != null)
			{
				_inMemoryTodoDatabase = initialDbState;
			}
			else
			{
				_inMemoryTodoDatabase = new GenericList<TodoItem>();
			}
		}


		public TodoItem Get(Guid todoId)
		{
			var q =
				from n in _inMemoryTodoDatabase
				where (n.Id.Equals(todoId))
				select n;
			return q.First();
		}

		public TodoItem Add(TodoItem todoItem)
		{
			_inMemoryTodoDatabase.Add(todoItem);
			return todoItem;
		}

		public bool Remove(Guid todoId)
		{
			var res =
				from it in _inMemoryTodoDatabase
				where (it.Id.Equals(todoId))
				select it;
			return _inMemoryTodoDatabase.Remove(res.FirstOrDefault());
		}

		public TodoItem Update(TodoItem todoItem)
		{
			if (_inMemoryTodoDatabase.Contains(todoItem))
			{
				_inMemoryTodoDatabase.Remove(todoItem);
			}
			_inMemoryTodoDatabase.Add(todoItem);

			return todoItem;
		}

		public bool MarkAsCompleted(Guid todoId)
		{

			TodoItem item = _inMemoryTodoDatabase.Where(s => s.Id == todoId)
												.FirstOrDefault();

			return item.MarkAsCompleted();
		}

		public List<TodoItem> GetAll()
		{
			var q = _inMemoryTodoDatabase.OrderByDescending(s => s.DateCreated)
											.Select(s => s);
			return q.ToList();
		}

		public List<TodoItem> GetActive()
		{
			return _inMemoryTodoDatabase.Where(s => !s.IsCompleted)
				.Select(s => s).ToList();
		}

		public List<TodoItem> GetCompleted()
		{
			return _inMemoryTodoDatabase.Where(s => s.IsCompleted)
				.Select(s => s).ToList();
		}

		public List<TodoItem> GetFiltered(Func<TodoItem, bool> filterFunction)
		{
			return _inMemoryTodoDatabase.Where(s => filterFunction(s))
				.Select(s => s).ToList();
		}



		public IEnumerator<TodoItem> GetEnumerator()
		{
			return new GenericListEnumerator<TodoItem>((GenericList<TodoItem>)_inMemoryTodoDatabase);
		}
	}
}