﻿using System;
using System.Data.Common;
using System.Linq;

namespace ConsoleApp1
{
	public class HomeworkLinqQueries
	{
		public static string[] Linq1(int[] intArray)
		{
			var q = from i in intArray
				group i by i
				into o
				select $"broj {o.Key} pojavljuje se {o.Count()} puta";
			return q.ToArray();
		}

		

		public static University[] Linq2_1(University[] universityArray)
		{
			var q = from uni in universityArray
				where uni.Students.Where(i => i.Gender==Gender.Male).Count()
				      == uni.Students.Length
				select uni;

			return q.ToArray();
		}

	}

	

	public class University
	{
		public string Name { get; set; }
		public Student[] Students { get; set; }

		University(Student[] studs)
		{
			Students = studs;
		}
	}

	
}
